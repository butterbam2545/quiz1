public class quiz1{
    public string university_name;
    public string libary_name;
    public string address;
    public double phone_number;

    public quiz1(string university_name, string libary_name, string address, double phone_number){
        this.university_name = university_name;
        this.libary_name = libary_name;
        this.address = address;
        this.phone_number = phone_number;
    }
}
